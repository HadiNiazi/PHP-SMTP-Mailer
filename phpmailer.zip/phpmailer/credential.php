<!DOCTYPE html>
<html>
<head>
	<title>Credential Page</title>
</head>
<body>

<?php

define('EMAIL', 'irshadahmedpk28@gmail.com');
define('PASS', 'raqdbsusebjifxhx');


?>


</body>
</html>