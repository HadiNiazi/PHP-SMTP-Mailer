<!DOCTYPE html>
<html>
<head>
	<title>Php Mailer</title>
	<link rel="stylesheet" type="text/css" href="bootstrap.min.css">


</head>
<body>

	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<h2 style="text-align: center;color: green">Php SMTP Mailer</h1>
				<form method="post" action="" style="margin-top: 50px">
					

				<div class="form-goup">
					<label>Email</label>
				<input type="text" name="email" class="form-control" placeholder="Enter Your email">
				</div>

				<div class="form-goup">
				<label>Subject</label>
				<input type="text" name="subject" class="form-control" placeholder="Enter Your subject">
				</div>

				<div class="form-goup">
				<label>Message</label>
				<textarea class="form-control">
				</textarea>
				</div>
				
				<div class="form-goup" style="margin-top: 10px">
				<input type="submit" name="submit" class="btn btn-primary btn-block" >
			</div>
				</form>
				
			</div>
		</div>
	</div>

	<?php


if (isset($_POST['submit'])) {

	require 'PHPMailerAutoload.php';
	require 'credential.php';

		$mail = new PHPMailer;

		$mail->SMTPDebug = 4;                               // Enable verbose debug output

		$mail->isSMTP();                                      // Set mailer to use SMTP
		$mail->Host = 'smtp.gmail.com;';  // Specify main and backup SMTP servers
		$mail->SMTPAuth = true;                               // Enable SMTP authentication
		$mail->Username = EMAIL;                 // SMTP username
		$mail->Password = PASS;                           // SMTP password
		// $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
		$mail->Port = 587;                                    // TCP port to connect to

		$mail->setFrom(EMAIL,'Testing Mailer');
		$mail->addAddress($_POST['email']);     // Add a recipient
		$mail->addAddress('ellen@example.com');               // Name is optional
		$mail->addReplyTo(EMAIL);

		// $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
		// $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
		$mail->isHTML(true);                                  // Set email format to HTML

		$mail->Subject = 'SMTP Testing';
		$mail->Body    = 'Hi <br><br> <b>I send a smtp testing mail!</b>';
		$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

		if(!$mail->send()) {
		    echo 'Message could not be sent.';
		    echo 'Mailer Error: ' . $mail->ErrorInfo;
		} else {
		    echo 'Message has been sent';
		}
}

	?>

</body>
</html>